# xmlrpc-bf
[PHP] Xmlrpc WordPress Brute force 

# Screenshot
![logo](https://user-images.githubusercontent.com/43511729/80187311-9dfbbc80-8639-11ea-9b01-1b516db568d0.jpg)

# How to use
  php xmlrpc.php [your site/xmlrpc.php] [user admin] [your list password]

# Example:
   php xmlrpc.php http://site.com/xmlrpc.php admin pass.txt
